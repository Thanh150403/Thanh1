package com.labsach.demo.controller;



import ch.qos.logback.core.model.Model;
import com.labsach.demo.entity.Book;
import com.labsach.demo.services.BookService;
import com.labsach.demo.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

//    @Autowired
//    private CategoryService categoryService;


    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }
    @GetMapping("/add")
    public String addBookForm(Model model) {

    }

    // Các phương thức khác có thể được thêm vào đây
}
