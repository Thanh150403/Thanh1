package validator;

public @interface ValidCategoryId {
}
